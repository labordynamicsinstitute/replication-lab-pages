---
layout: post
date: 2016-01-15 07:59:00-0400
inline: true
---

A simple inline announcement with Markdown emoji! :sparkles: :smile:
